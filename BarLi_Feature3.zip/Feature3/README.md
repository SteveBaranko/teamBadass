Barli web app README

Authors: Steven Baranko, Yiming Li

For more information, navigate to parent directory and look at the README. 

This is a Web Application meant as an online discussion forum for experts. 

Our current tech stack: 

	Front End: Preact

	Styling: Tailwind CSS

	Http Requests: Axios

	Version control: Git

