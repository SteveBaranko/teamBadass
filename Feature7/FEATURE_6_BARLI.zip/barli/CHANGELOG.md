## [Version 0.4.0]
  -TODO add comments
  -TODO fix legacy deps
## Added
  Firebase 
  Firestore
  Firebase Auth 
  Lots of new styling
  Email verification
  
## [Version 0.3.0]
  -TODO: start updating changelog for minor changes
## Added 
  -Auth that is dependent on Browser Cache (kinda yikes maybe fix)
  -Advanced Routing 
  -vibes


## [Version 0.2.0]
## Added 
  -Parse Database support (to be removed)
  -Routing
  -Comment List
  -Post List
  -Navbar
  -tailwind
  -Styling
  -React

## Removed 
  -Preact

## Notable Tech Stack Changes
  -React instead of Preact
  -Parse added
  -Tailwind Added
  -react-router-dom v6 added
  TODO: Add versions of all of those things for maintanence

## Security
  -None lol


