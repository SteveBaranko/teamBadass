import { useDispatch, useSelector } from "react-redux";
import type { TypedUseSelectorHook } from "react-redux";

import { AppDispatch, RootState } from "../store";

export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
//this is our store hook
//it is used to get the dispatch and the state from the store
//if you are unfamiliar with redux, you can read more about it here: https://redux.js.org/