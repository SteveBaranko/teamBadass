import React, { useEffect } from "react";
import Header from "../../components/Header/Header";
import { homeClasses } from "./HomeClasses";
import PostList from "../../components/PostStuff/PostList";
import PostForm from "../../components/PostStuff/PostForm";
import { useAppSelector } from "../../hooks/StoreHook"; 
import { useNavigate } from "react-router-dom";
import { deleteUser } from "firebase/auth";
import { getAuth, } from "firebase/auth";


const Home = () => {
  const navigate = useNavigate();
  const { container, cardContainer, title, description } = homeClasses;
  const auth = useAppSelector((state) => state.auth);


  useEffect(() => {
    const deleteUserIfNotVerified = async () => {
      const user = auth.user;
      if (user && !user.emailVerified) {
        try {
          const auth = getAuth();
          await deleteUser(auth.currentUser!);
          navigate("/auth");
        } catch (error) {
          console.log("Error deleting user:", error);
        }
      }
    };
    deleteUserIfNotVerified();
  }, []);
  

  return (
    <>
      <Header />
    
      {auth.user ? <PostForm /> : <p></p>}

      <PostList />
    </>
  );
};
 
export default Home;