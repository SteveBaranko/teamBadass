export const homeClasses = {
  container: "grid place-content-center w-full h-[80vh]",
  cardContainer: "max-w-lg p-6 mx-auto bg-white border border-gray-200 rounded-lg shadow-md mt-8",
  title: "mb-2 text-2xl font-bold tracking-tight",
  description: "font-normal",
};