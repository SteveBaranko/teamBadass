export const emailVerificationClasses = {
  container: "grid place-content-center w-full h-[80vh]",
  cardContainer: "block max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow hover:bg-gray-100 bg-gray-800 border-gray-700 hover:bg-gray-700 hover:text-white",
  title: "mb-2 text-2xl font-bold tracking-tight",
  description: "font-normal",
  warning: "text-red-500",
  button: "px-4 py-2 mt-4 text-white bg-green-500 rounded hover:bg-green-600",
};