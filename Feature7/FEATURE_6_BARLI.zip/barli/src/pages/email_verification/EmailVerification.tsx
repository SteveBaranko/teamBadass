import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth } from "../../config/firebase";
import { emailVerificationClasses } from "./EmailVerificationClasses";
import { useDispatch } from "react-redux";
import { login, logout } from "../../features/authSlice";
import { deleteUser, getAuth, onAuthStateChanged } from "firebase/auth";
import { set } from "react-hook-form";

const EmailVerification = () => {
  const { container, cardContainer, title, description, warning } =
    emailVerificationClasses;
  const [emailVerified, setEmailVerified] = useState(false);
  const navigate = useNavigate();
  const user = auth.currentUser;
  const dispatch = useDispatch();

  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user && user.emailVerified === true && !emailVerified) {
        try {
          setEmailVerified(true);
          dispatch(
            login({
              email: user.email || "",
              id: user.uid,
              photoUrl: user?.photoURL || null,
              emailVerified: true,
            })
          );
        } catch (error) {
          console.log("Error checking email verification:", error);
        }

        navigate("/");
      }
    });
    return () => unsubscribe();
  }, []);

  const checkEmailVerification = async () => {
    const user = auth.currentUser;
    if (user) {
      try {
        await user.reload();
        if (user.emailVerified) {
          setEmailVerified(true);
          dispatch(
            login({
              email: user.email || "",
              id: user.uid,
              photoUrl: user?.photoURL || null,
              emailVerified: true,
            })
          );
          navigate("/");
        } else {
          setEmailVerified(false);
          navigate("/verification");
        }
      } catch (error) {
        console.log("Error checking email verification:", error);
      }
    }
  };

  const handleCheckEmailVerification = () => {
    checkEmailVerification();
  };

  return (
    <div className={container}>
      <div className={cardContainer}>
        <h5 className={title}>Email Verification</h5>
        {!emailVerified ? (
          <>
            <p className={description}>Please verify your email address.</p>
            <p className={warning}>
              Warning: Do not proceed without email verification.
            </p>
          </>
        ) : (
          <p className={description}>
            Your email has been verified. You can now access all features.
          </p>
        )}
        {!emailVerified && (
          <button
            className={emailVerificationClasses.button}
            onClick={handleCheckEmailVerification}
          >
            Check Email Verification
          </button>
        )}
      </div>
    </div>
  );
};

export default EmailVerification;