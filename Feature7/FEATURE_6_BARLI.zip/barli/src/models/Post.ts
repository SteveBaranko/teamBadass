import firebase from "firebase/compat/app";


export interface Post {
  id: string;
  title: string;
  content: string;
  likes: number;
  liked: boolean;
  dislikes: number;
  disliked: boolean;
  createdAt: firebase.firestore.Timestamp;
  author: string;
  authorId: string;
}

//this is our post model