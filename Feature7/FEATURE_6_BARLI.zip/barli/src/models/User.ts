export interface User {
  email: string;
  id: string;
  photoUrl: string | null;
  emailVerified: boolean;
}
//this is our user model