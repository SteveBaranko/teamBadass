import * as yup from "yup";
//for info on yup, see https://www.npmjs.com/package/yup?activeTab=readme
export const authFormSchema = yup.object().shape({
  email: yup
    .string()
    .email("Please provide a valid email address")
    .required("Email address is required"),
  password: yup
    .string()
    .min(8, "Password should be a minimum length of 8")
    .max(20, "Password should be a maximum length of 20")
    //this line was pain. Could be useful to add in the future.
    //it was also found on stack overflow (i forgot where tho yikes)
    .matches(/((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/, {
      message: "Password is too weak",
    })
    .test("wrongPassword", "Wrong password", (value, { parent }) => {
      const { authType } = parent;
      if (authType === "login" && value !== "correct-password") {
        return false;
      }
      return true;
    })
    .required("Password is required"),
    confirmPassword: yup
    .string()
    .oneOf([yup.ref("password")], "Passwords do not match")
});
export interface AuthForm {
  email: string;
  password: string;
  confirmPassword?: string;
  authType?: "login" | "sign-up";
  emailVerified?: boolean;
  passwordError?: string;
}