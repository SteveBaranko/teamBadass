import { Routes, Route } from "react-router-dom";
import { useEffect } from "react";

import Home from "./pages/home/Home";
import Auth from "./pages/auth/Auth";
import Profile from "./pages/profile/Profile";
import { auth } from "./config/firebase";
import { useAppDispatch } from "./hooks/StoreHook";
import { login, logout } from "./features/authSlice";
import AuthRoutes from "./components/HOC/AuthRoutes";
import EmailVerification from "./pages/email_verification/EmailVerification";
import { useNavigate } from "react-router-dom";


//credit to github/laribright

//for more information look at 
/*
    laribright
    /
    udemy-firebase-auth
*/




const App = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {

      if (user && !user.emailVerified) {
        dispatch(
          login({
            email: user.email || "",
            id: user.uid,
            photoUrl: user?.photoURL || null,
            emailVerified: user.emailVerified,
          })
        );
        return navigate("/verification");

      } else if (user && user.emailVerified) {

        if (user && user.email)
          dispatch(
            login({
              email: user.email,
              id: user.uid,
              photoUrl: user?.photoURL || null,
              emailVerified: user.emailVerified,
            })
          );
        navigate("/");
      } 
    });

    return () => unsubscribe();
  }, [dispatch]);

  return (
    <div className="bg-gray-900 h-screen w-screen">
      <Routes>
        <Route element={<AuthRoutes />}>
          <Route path="profile" element={<Profile />} />
        </Route>
        <Route path="/" element={<Home />} />
        <Route path="auth" element={<Auth />} />
        <Route path="verification" element={<EmailVerification />} />
      </Routes>
    </div>
  );
};

export default App;