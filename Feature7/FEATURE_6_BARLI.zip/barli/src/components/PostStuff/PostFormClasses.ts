export const postFormClasses = {
  container: "max-w-xl p-6 bg-gray-800 text-white border border-gray-200 rounded-lg shadow-md mt-8",
  form: "grid gap-y-4",
  input: "w-full px-3 py-2 border rounded text-black", 
  textarea: "w-full h-40 px-3 py-2 border rounded text-black", 
  submitButton: "py-2 px-4 rounded bg-green-500 text-white font-bold",
  successMessage: "text-green-600 font-bold mt-4",
  errorMessage: "text-red-600 font-bold mt-4",
  newPostButton: "py-2 px-4 rounded bg-green-500 text-white font-bold ml-4",
};