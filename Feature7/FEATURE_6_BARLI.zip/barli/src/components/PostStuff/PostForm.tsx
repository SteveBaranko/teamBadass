import React, { useState } from "react";
import { db } from "../../config/firebase";
import { collection, serverTimestamp, addDoc } from "firebase/firestore";
import { postFormClasses } from "./PostFormClasses";
import { useAppSelector } from "../../hooks/StoreHook";

/*
This is our Post form. It should only render if the user is logged in. 
If this renders and the user isn't logged in, the mistake isn't in this file.
It would be in the Home.tsx file.
*/
const PostForm = () => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [showForm, setShowForm] = useState(false); 


  const auth = useAppSelector((state) => state.auth);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await addDoc(collection(db, "posts"), {
        title: title,
        content: content,
        likes: 0,
        dislikes: 0,
        createdAt: serverTimestamp(),
        author: auth.user?.email,
        authorId: auth.user?.id,
      });

      setTitle("");
      setContent("");
      setSuccessMessage("Post submitted successfully!");
      setErrorMessage("");
      setShowForm(false);
    } catch (error) {
      setErrorMessage("Error adding post:");
      setSuccessMessage("");
    }
  };

  const toggleFormVisibility = () => {
    setShowForm((prevShowForm) => !prevShowForm);
  };

  if (!auth.user) {
    return (
      <div>
        {errorMessage && <div className={postFormClasses.errorMessage}>{errorMessage}</div>}
        <p>Please log in to post.</p>
      </div>
    )
  }

  if (showForm) {
    return (
      <div className={postFormClasses.container}>
        <form className={postFormClasses.form} onSubmit={handleSubmit}>
          {successMessage && <div className={postFormClasses.successMessage}>{successMessage}</div>}
          {errorMessage && <div className={postFormClasses.errorMessage}>{errorMessage}</div>}
          <div>
            <label htmlFor="title">Title:</label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className={postFormClasses.input}
              placeholder="Enter a title..."
            />
          </div>
          <div>
            <label htmlFor="content">Content:</label>
            <textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className={postFormClasses.textarea}
              placeholder="Write your post content..."
            />
          </div>
          <button type="submit" className={postFormClasses.submitButton}>
            Submit
          </button>
        </form>
      </div>
    );
  } else {
    return (
      <div>
        <button onClick={toggleFormVisibility} className={postFormClasses.newPostButton}>
          Create New Post
        </button>
      </div>
    );
  }
};

export default PostForm;