import React, { useState, useEffect } from "react";
import { FieldValue, collection, doc, getDoc, getDocs, onSnapshot, query, updateDoc, where } from "firebase/firestore";
import { db } from "../../config/firebase";
import { Post } from "../../models/Post";
import { csPostListClasses } from "./PostListClasses";
import { FaThumbsUp, FaThumbsDown, FaComment } from "react-icons/fa"; 
import { get } from "react-hook-form";
import { getAuth, onAuthStateChanged } from "firebase/auth";
import { useNavigate } from "react-router-dom";

/*
This is our bulk main list component for posts
TODO: add comment functionality (still doesn't work :( )

*/

interface PostItem {
  id: string;
  title: string;
  content: string;
  likes: number;
  dislikes: number;
  liked: boolean;
  disliked: boolean;
  author: string;
  authorId: string;
  createdAt: FieldValue;
}


const PostList: React.FC = () => {
  const [posts, setPosts] = useState<PostItem[]>([]);
  const auth = getAuth();

  const user = auth.currentUser;
  const navigate = useNavigate();

  useEffect(() => {
    const postsRef = collection(db, "posts");

    const unsubscribe = onSnapshot(postsRef, (querySnapshot) => {
      const updatedPosts: PostItem[] = [];
      querySnapshot.forEach((doc) => {
        const post = doc.data() as Post;
        const postItem: PostItem = {
          id: doc.id,
          title: post.title,
          content: post.content,
          likes: post.likes,
          dislikes: post.dislikes,
          liked: false,
          disliked: false,
          author: post.author,
          authorId: post.authorId,
          createdAt: post.createdAt,
        };
        updatedPosts.push(postItem);
      });
      setPosts(updatedPosts);
    });

    return () => unsubscribe();
  }, []);

  const handleLike = async (postId: string) => {
    if (!user) {
      return navigate("/auth");
    }
    const postRef = doc(db, "posts", postId);
    const postSnapshot = await getDoc(postRef);
    if (postSnapshot.exists()) {
      const post = postSnapshot.data() as PostItem;
      const newLikes = post.liked ? post.likes - 1 : post.likes + 1;
      const newLiked = !post.liked;
      await updateDoc(postRef, { likes: newLikes, liked: newLiked });
    }
  };


  const handleDislike = async (postId: string) => {
    if (!user) {
      return navigate("/auth");
    }
    const postRef = doc(db, "posts", postId);
    const postSnapshot = await getDoc(postRef);
    if (postSnapshot.exists()) {
      const post = postSnapshot.data() as PostItem;
      const newDislikes = post.disliked ? post.dislikes - 1 : post.dislikes + 1;
      const newDisliked = !post.disliked;
      await updateDoc(postRef, { dislikes: newDislikes, disliked: newDisliked });
    }
  };



  return (
    <div className={csPostListClasses.container}>
      <h2 className={csPostListClasses.postTitle}>Post List</h2>
      {posts.map((post) => (
        <div key={post.id} className={csPostListClasses.post}>
          <h4 className={csPostListClasses.postAuthor}>{post.author}</h4>
          <h3 className={csPostListClasses.postTitle}>{post.title}</h3>
          <div className={csPostListClasses.postContentContainer}>
            <p className={csPostListClasses.postContent}>{post.content}</p>
            <div className={csPostListClasses.likeContainer}>
              <div onClick={() => handleLike(post.id)} className={csPostListClasses.likeButton}>
                {post.liked ? <FaThumbsUp color="green" /> : <FaThumbsUp />}
              </div>
              <p className={csPostListClasses.likesCount}>
                {post.likes} 
              </p>
              <div onClick={() => handleDislike(post.id)} className={csPostListClasses.dislikeButton}>
                {post.disliked ? <FaThumbsDown color="red" /> : <FaThumbsDown />}
              </div>
              <p className={csPostListClasses.dislikesCount}>
                {post.dislikes} 
              </p>
              <div className={csPostListClasses.commentButton}>
                <FaComment /> 
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default PostList;

