import React, { useState, useEffect } from "react";
import { Post } from "../../models/Post";
import { csPostListClasses } from "./PostListClasses";
import { FaThumbsUp, FaThumbsDown, FaComment } from "react-icons/fa";
import { db } from "../../config/firebase";
import { collection, doc, updateDoc, serverTimestamp, onSnapshot, addDoc, query, where } from "firebase/firestore";

/*
Our Post component. It really should not let the user like and dislike a comment.
Oh well! It's a feature, not a bug!
*/
interface PostProps {
  post: Post;
}

export interface PostItem extends Post {
  showCommentForm: boolean;
  liked: boolean;
}


const PostItem: React.FC<PostProps> = ({ post }) => {
  const [liked, setLiked] = useState<boolean>(false);
  const [disliked, setDisliked] = useState<boolean>(false);
  const [likes, setLikes] = useState<number>(post.likes);
  const [dislikes, setDislikes] = useState<number>(post.dislikes);
 



  const handleLike = async () => {
    if (disliked) {
      setDisliked(false);
      setDislikes((prevDislikes) => prevDislikes - 1);
    }

    setLiked((prevLiked) => !prevLiked);
    setLikes((prevLikes) => (prevLikes ? prevLikes - 1 : prevLikes + 1));

    await updateDoc(doc(db, "posts", post.id), {
      likes: liked ? post.likes - 1 : post.likes + 1,
    });
  };

  const handleDislike = async () => {
    if (liked) {
      setLiked(false);
      setLikes((prevLikes) => prevLikes - 1);
    }
    setDisliked((prevDisliked) => !prevDisliked);
    setDislikes((prevDislikes) => (prevDislikes ? prevDislikes - 1 : prevDislikes + 1));

    await updateDoc(doc(db, "posts", post.id), {
      dislikes: disliked ? post.dislikes - 1 : post.dislikes + 1,
    });
  };


  return (
    <div className={csPostListClasses.post}>
      <h4 className={csPostListClasses.postAuthor}>{post.author}</h4>
      <h3 className={csPostListClasses.postTitle}>{post.title}</h3>
      <div className={csPostListClasses.postContentContainer}>
        <p className={csPostListClasses.postContent}>{post.content}</p>
        <div className={csPostListClasses.likeContainer}>
          <div onClick={handleLike} className={csPostListClasses.likeButton}>
            {liked ? <FaThumbsUp color="green" /> : <FaThumbsUp />}
          </div>
          <p className={csPostListClasses.likesCount}>{likes}</p>
          <div onClick={handleDislike} className={csPostListClasses.dislikeButton}>
            {disliked ? <FaThumbsDown color="red" /> : <FaThumbsDown />}
          </div>
          <p className={csPostListClasses.dislikesCount}>{dislikes}</p>
        </div>
      </div>
    </div>
  );
};

export default PostItem;
