import { Navigate, Outlet } from "react-router-dom";

import { useAppSelector } from "../../hooks/StoreHook";

const AuthRoutes = () => {
  const { user } = useAppSelector((state) => state.auth);

  return Boolean(user) ? <Outlet /> : <Navigate to="/auth" />;
};

export default AuthRoutes;