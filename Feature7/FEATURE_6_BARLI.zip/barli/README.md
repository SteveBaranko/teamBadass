This is our project, our baby, so please enjoy. 
But first, if you are unfamiliar with our tech stack, you might have some 
reading to do before you can truly dive in. 

Authors: Steven Baranko and Yiming Li

Check our our Githubs: 
  YimingLi9806
  SteveBarano

We are sick and awesome to hire! 

Our tech Stack

Frontend:
  React
  Babel
  Tailwind
  Yup 

State
  Redux
  useState

Backend
  Firestore

Auth
  Firebase Auth

Routing 
  React-router-dom v6

Language:
  Typescript

Other:
  react-icons/fa

I think that's all?